document.addEventListener('DOMContentLoaded', function() {
    // menu cuy
    const menu = document.querySelector('#menu-icon');
    const navlist = document.querySelector('.navlist');
    menu.onclick = () => {
        menu.classList.toggle('bx-x');
        navlist.classList.toggle('open');
    };
    window.onscroll = () => {
        menu.classList.remove('bx-x');
        navlist.classList.remove('open');
    };

    // search euy
    const searchIcon = document.getElementById("search-icon");
    const searchInput = document.getElementById("search-input");
    searchIcon.addEventListener("click", function(event) {
        event.preventDefault();
        searchInput.style.display = searchInput.style.display === "none" ? "block" : "none";
        if (searchInput.style.display === "block") searchInput.focus();
    });
    searchInput.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            const query = searchInput.value.trim().toLowerCase();
            const sectionMap = { "home": "#home", "shop": "#shop", "feature": "#feature", "pages": "#pages", "blogs": "#blogs", "contact": "#contact" };
            if (sectionMap[query]) {
                window.location.hash = sectionMap[query];
                searchInput.value = "";
                searchInput.style.display = "none";
            } else {
                alert("Bagian tidak ditemukan. Coba 'Home', 'Shop', 'Feature', 'Pages', 'Blogs', atau 'Contact'.");
            }
        }
    });

// cart eyy
const cartModal = document.querySelector('.cart-modal');
const shoppingBagIcon = document.querySelector('.ri-shopping-bag-line');
const cartContent = cartModal.querySelector('.cart-content');
const totalPriceElement = document.createElement('div');
totalPriceElement.className = 'total-price';
cartContent.appendChild(totalPriceElement);

const payButton = document.createElement('button'); 
payButton.className = 'pay-button';
payButton.textContent = 'Bayar Pesanan'; 
cartModal.appendChild(payButton);

let cartItems = [];
let totalPrice = 0;

function addToCart(item) {
    cartItems.push(item);
    updateCart();
    triggerShakeAnimation();
}

function removeFromCart(itemName) {
    cartItems = cartItems.filter(item => item.name !== itemName);
    updateCart();
}

function updateCart() {
    cartContent.innerHTML = ''; 
    let total = 0;
    cartItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `
            <h5>${item.name}</h5>
            <h6>${item.price}</h6>
            <button class="remove-item-btn">Hapus</button>
        `;
        cartContent.appendChild(itemElement);

       
        itemElement.querySelector('.remove-item-btn').addEventListener('click', function() {
            removeFromCart(item.name);
        });

        total += parseInt(item.price.replace(/\D/g, ''));
    });
    totalPriceElement.innerHTML = `<h5>Total Harga: Rp ${total.toLocaleString()}</h5>`;
}

function triggerShakeAnimation() {
    shoppingBagIcon.classList.add('shake');
    setTimeout(() => shoppingBagIcon.classList.remove('shake'), 500);
}

shoppingBagIcon.addEventListener('click', function(event) {
    event.preventDefault();
    cartModal.style.display = 'block';
});

document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault();
        const itemName = event.target.closest('.row').querySelector('h5').dataset.name;
        const itemPrice = event.target.closest('.row').querySelector('h6').dataset.price;
        addToCart({ name: itemName, price: itemPrice });
    });
});

// pembayaran
payButton.addEventListener('click', function() {
    if (cartItems.length === 0) {
        alert("Keranjang belanja kosong. Tambahkan item untuk melanjutkan pembayaran.");
        return;
    }

    const totalAmount = totalPriceElement.textContent.replace(/[^0-9]/g, '');
    alert(`Pembayaran berhasil! Total yang harus dibayar: Rp ${parseInt(totalAmount).toLocaleString()}`);
    

    cartItems = [];
    updateCart();
    cartModal.style.display = 'none'; 
});


});
document.addEventListener('DOMContentLoaded', function() {
    const userIcon = document.getElementById('user-icon');
    const loginModal = document.getElementById('login-modal');
    const closeBtn = document.querySelector('.close-btn');

    
    userIcon.addEventListener('click', function(event) {
        event.preventDefault();
        loginModal.style.display = 'block';
    });

    
    closeBtn.addEventListener('click', function() {
        loginModal.style.display = 'none';
    });

    
    window.addEventListener('click', function(event) {
        if (event.target === loginModal) {
            loginModal.style.display = 'none';
        }
    });
});
